#!/usr/bin/env node
'use strict';
const path = require('path');
const bytenode = require('bytenode');
require(path.join(__dirname, 'server.jsc'));
