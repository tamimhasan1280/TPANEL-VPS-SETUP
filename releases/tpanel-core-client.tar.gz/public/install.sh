#!/usr/bin/env bash
# ==============================================================================
# TPANEL MASTER CLUSTER & CONTROL ENGINE INSTALLER
# Production Automated Installation Script for Ubuntu 20.04/22.04/24.04 & Debian
# Repository: https://github.com/abbas1280-dev/Cpanel1280
# ==============================================================================

set -e

# 1. Root Check
if [ "$EUID" -ne 0 ]; then
    echo "❌ Error: This script must be run as root. Run with 'sudo bash install.sh'"
    exit 1
fi

# Attach to /dev/tty if running via curl pipe so interactive prompts work seamlessly
if [ ! -t 0 ] && [ -e /dev/tty ]; then
    exec < /dev/tty
fi

# ------------------------------------------------------------------------------
# 2. BRANDED TPANEL BANNER & LICENSE / ADMIN CREDENTIAL SETUP
# ------------------------------------------------------------------------------
echo ""
cat << 'EOF'
  ______ _____                 _ 
 |_   __|  __ \               | |
   | |  | |__) |_ _ _ __   ___| |
   | |  |  ___/ _` | '_ \ / _ \ |
  _| |_ | |  | (_| | | | |  __/ |
 |_____||_|   \__,_|_| |_|\___|_|
==========================================================================
  🚀 WELCOME TO TPANEL CLOUD HOSTING & CONTROL ENGINE
  ⚡ Autonomous Linux Hosting, Mail Engine & Cryptographic Stack
  🌐 Official Portal: https://hoster1280.shop
==========================================================================
EOF
echo ""

# Detect Server IP early for activation
SERVER_IP=$(curl -s -4 --connect-timeout 4 https://api.ipify.org || curl -s --connect-timeout 4 https://ifconfig.me || hostname -I | awk '{print $1}')
if [ -z "$SERVER_IP" ]; then
    SERVER_IP="127.0.0.1"
fi

# Ensure machine hardware ID exists
MACHINE_ID=""
if [ -f /etc/machine-id ]; then
    MACHINE_ID=$(cat /etc/machine-id | tr -d '\r\n ')
elif [ -f /var/lib/dbus/machine-id ]; then
    MACHINE_ID=$(cat /var/lib/dbus/machine-id | tr -d '\r\n ')
fi
if [ -z "$MACHINE_ID" ]; then
    MACHINE_ID=$(cat /proc/sys/kernel/random/uuid 2>/dev/null || date +%s%N)
    mkdir -p /etc
    echo "$MACHINE_ID" > /etc/machine-id
fi

# Step 1: License Key Prompt & Handshake
LICENSE_KEY="${TPANEL_LICENSE_KEY:-}"
while [ -z "$LICENSE_KEY" ]; do
    echo "🔐 STEP 1/2: LICENSE KEY VERIFICATION (লাইসেন্স কি যাচাইকরণ)"
    echo "--------------------------------------------------------------------------"
    read -r -p "🔑 Enter your Tpanel License Key: " LICENSE_KEY
    LICENSE_KEY=$(echo "$LICENSE_KEY" | tr -d ' ' | tr '[:lower:]' '[:upper:]')
    if [ -z "$LICENSE_KEY" ]; then
        echo "❌ License key cannot be blank. Please enter a valid key."
        echo ""
    fi
done

echo ""
echo "⏳ Validating license with Tpanel Central Hub (hoster1280.shop)..."
ACTIVATE_PAYLOAD=$(printf '{"licenseKey":"%s","machineId":"%s","vpsIp":"%s","hostname":"%s"}' "$LICENSE_KEY" "$MACHINE_ID" "$SERVER_IP" "$(hostname)")
ACTIVATE_RESP=$(curl -s -X POST "https://hoster1280.shop/api/license/activate" \
    -H "Content-Type: application/json" \
    --connect-timeout 8 \
    -d "$ACTIVATE_PAYLOAD" 2>/dev/null || true)

ACTIVATE_SUCCESS=$(echo "$ACTIVATE_RESP" | grep -o '"success":true' || true)

if [ -z "$ACTIVATE_SUCCESS" ]; then
    ERR_MSG=$(echo "$ACTIVATE_RESP" | grep -o '"error":"[^"]*' | cut -d'"' -f4 || echo "License validation failed. Cannot reach licensing authority.")
    echo ""
    echo "=========================================================================="
    echo "❌ LICENSE ACTIVATION REJECTED!"
    echo "=========================================================================="
    echo "  Reason: ${ERR_MSG}"
    echo "  Please verify your license key with the server owner or obtain a valid key."
    echo "  Support & Inquiries: tamimhasan1281@gmail.com | https://hoster1280.shop"
    echo "=========================================================================="
    echo ""
    exit 1
fi

OWNER_NAME=$(echo "$ACTIVATE_RESP" | grep -o '"owner_name":"[^"]*' | cut -d'"' -f4 || echo "Authorized Client")
MAX_INST=$(echo "$ACTIVATE_RESP" | grep -o '"max_instances":[0-9]*' | cut -d':' -f2 || echo "1")

echo "✅ License Verified & Bound Successfully!"
echo "   👤 Licensed To    : ${OWNER_NAME}"
echo "   🖥️ Instance Quota : ${MAX_INST} VPS Instance(s)"
echo "   🔒 Hardware ID    : ${MACHINE_ID:0:16}..."
echo ""

# Store Cryptographically Signed Token
mkdir -p /etc/tpanel
echo "$ACTIVATE_RESP" | grep -o '"token":{[^}]*}' | sed 's/"token"://' > /etc/tpanel/.license 2>/dev/null || echo "$ACTIVATE_RESP" > /etc/tpanel/.license
chmod 600 /etc/tpanel/.license

# Step 2: Administrator Account Setup
echo "--------------------------------------------------------------------------"
echo "👤 STEP 2/2: ADMINISTRATOR ACCOUNT SETUP (মাস্টার অ্যাডমিন একাউন্ট)"
echo "--------------------------------------------------------------------------"
echo "  Create your primary administrative credentials for the Tpanel dashboard."
echo ""

ADMIN_EMAIL="${TPANEL_ADMIN_EMAIL:-}"
while [ -z "$ADMIN_EMAIL" ]; do
    read -r -p "📧 Administrator Email: " ADMIN_EMAIL
    ADMIN_EMAIL=$(echo "$ADMIN_EMAIL" | tr -d ' ')
    if [ -z "$ADMIN_EMAIL" ]; then
        echo "❌ Email cannot be blank."
    fi
done

prompt_password() {
    local prompt="$1"
    local password=""
    local char
    echo -n "$prompt" >&2
    while IFS= read -r -s -n 1 char; do
        if [[ $char == $'\0' || $char == $'\n' ]]; then
            break
        elif [[ $char == $'\177' || $char == $'\b' ]]; then
            if [ ${#password} -gt 0 ]; then
                password="${password%?}"
                echo -ne "\b \b" >&2
            fi
        else
            password+="$char"
            echo -n "*" >&2
        fi
    done
    echo "" >&2
    echo "$password"
}

ADMIN_PASS="${TPANEL_ADMIN_PASS:-}"
if [ -z "$ADMIN_PASS" ]; then
    while true; do
        ADMIN_PASS=$(prompt_password "🔒 Administrator Password: ")
        if [ ${#ADMIN_PASS} -lt 6 ]; then
            echo "❌ Password must be at least 6 characters long."
            continue
        fi
        ADMIN_PASS_CONFIRM=$(prompt_password "🔒 Confirm Administrator Password: ")
        if [ "$ADMIN_PASS" != "$ADMIN_PASS_CONFIRM" ]; then
            echo "❌ Passwords do not match. Please re-enter."
            continue
        fi
        break
    done
fi

echo ""
echo "✅ Administrator credentials verified."
echo "🚀 Proceeding with automated system installation..."
echo "=========================================================================="
echo ""

export DEBIAN_FRONTEND=noninteractive

# 3. System Update & Essential Tools
echo "🔄 Updating package lists and installing core dependencies..."
apt-get update -y -q
apt-get install -y -q \
    curl wget git software-properties-common ca-certificates \
    lsb-release apt-transport-https build-essential ufw zip unzip tar \
    nano jq net-tools dnsutils ssl-cert

# 4. Install Nginx Web Server
echo "🌐 Installing Nginx Web Server..."
systemctl stop apache2 2>/dev/null || true
systemctl disable apache2 2>/dev/null || true

if [ ! -f /etc/nginx/nginx.conf ]; then
    echo "🔄 Restoring Nginx base configurations..."
    apt-get install --reinstall -o Dpkg::Options::="--force-confmiss" -y -q nginx nginx-common 2>/dev/null || true
else
    apt-get install -y -q nginx 2>/dev/null || true
fi
mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled /etc/nginx/conf.d
systemctl enable nginx 2>/dev/null || true
systemctl start nginx 2>/dev/null || true

# 5. Install MariaDB Database Server
echo "🗄️ Installing MariaDB Database Engine..."
if [ ! -d /etc/mysql ]; then
    echo "🔄 Restoring MariaDB base configurations..."
    apt-get install --reinstall -o Dpkg::Options::="--force-confmiss" -y -q mariadb-server mariadb-client 2>/dev/null || true
else
    apt-get install -y -q mariadb-server mariadb-client 2>/dev/null || true
fi
systemctl enable mariadb 2>/dev/null || true
systemctl start mariadb 2>/dev/null || true

# 6. Install Node.js LTS (v20)
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | cut -d'.' -f1 | tr -d 'v')" -lt 18 ]; then
    echo "🟢 Installing Node.js LTS (v20)..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y -q nodejs
fi
echo "✅ Node.js $(node -v) & NPM $(npm -v) ready."

# 7. Install PHP FastCGI & Multi-Version Extensions
echo "🐘 Installing PHP Runtime & Modules..."
if [ "$OS_NAME" = "ubuntu" ]; then
    add-apt-repository -y ppa:ondrej/php || true
    apt-get update -y -q
fi

apt-get install -y -q \
    php8.2-fpm php8.2-mysql php8.2-cli php8.2-curl php8.2-gd php8.2-mbstring \
    php8.2-xml php8.2-zip php8.2-bcmath php8.2-soap php8.2-intl || true

# Optional auxiliary PHP versions
apt-get install -y -q php8.1-fpm php8.1-mysql php8.1-cli php8.1-curl php8.1-gd php8.1-mbstring php8.1-xml php8.1-zip || true
apt-get install -y -q php8.3-fpm php8.3-mysql php8.3-cli php8.3-curl php8.3-gd php8.3-mbstring php8.3-xml php8.3-zip || true

systemctl enable php8.2-fpm || true
systemctl start php8.2-fpm || true

# 8. Install Mail Server Stack (Postfix + Dovecot)
echo "✉️ Installing In-House Mail Stack (Postfix SMTP & Dovecot Maildir)..."
debconf-set-selections <<< "postfix postfix/mailname string localhost"
debconf-set-selections <<< "postfix postfix/main_mailer_type string 'Internet Site'"

apt-get install -y -q \
    postfix postfix-mysql \
    dovecot-core dovecot-imapd dovecot-pop3d dovecot-lmtpd dovecot-mysql \
    bind9 bind9utils certbot python3-certbot-nginx

# 9. Create Dedicated vmail User & Storage
echo "📂 Configuring Maildir and Web Hosting Directories..."
groupadd -g 5000 vmail 2>/dev/null || true
useradd -g vmail -u 5000 vmail -d /var/vmail -m -s /usr/sbin/nologin 2>/dev/null || true
mkdir -p /var/vmail /var/www/vhosts /etc/postfix/sql /etc/dovecot/conf.d /var/cpanel/backups
chown -R vmail:vmail /var/vmail
chmod -R 770 /var/vmail

# 10. Locate or Clone Repository Source Files
REPO_URL="${REPO_URL:-https://github.com/abbas1280-dev/Cpanel1280.git}"
APP_DIR="/opt/cpanel-core"

# Check if script is running from an existing cloned repo
if [ -n "${BASH_SOURCE[0]}" ] && [ -f "$(dirname "${BASH_SOURCE[0]}")/server.js" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    echo "📁 Source files detected locally at ${SCRIPT_DIR}"
else
    echo "📥 Installer running via pipe/remote. Cloning Cpanel1280 repository..."
    TEMP_CLONE_DIR=$(mktemp -d)
    git clone --depth 1 "${REPO_URL}" "${TEMP_CLONE_DIR}"
    SCRIPT_DIR="${TEMP_CLONE_DIR}"
fi

echo "⚙️ Applying Postfix & Dovecot Configuration Templates..."
if [ -d "${SCRIPT_DIR}/configs/postfix" ]; then
    cp -f "${SCRIPT_DIR}/configs/postfix/main.cf" /etc/postfix/main.cf
    cp -f "${SCRIPT_DIR}/configs/postfix/master.cf" /etc/postfix/master.cf
    cp -rf "${SCRIPT_DIR}/configs/postfix/sql/"* /etc/postfix/sql/
    chmod 640 /etc/postfix/sql/*.cf || true
fi

if [ -d "${SCRIPT_DIR}/configs/dovecot" ]; then
    cp -f "${SCRIPT_DIR}/configs/dovecot/dovecot.conf" /etc/dovecot/dovecot.conf
    cp -f "${SCRIPT_DIR}/configs/dovecot/dovecot-sql.conf.ext" /etc/dovecot/dovecot-sql.conf.ext
    cp -rf "${SCRIPT_DIR}/configs/dovecot/conf.d/"* /etc/dovecot/conf.d/
    chmod 640 /etc/dovecot/dovecot-sql.conf.ext || true
fi

# Ensure snakeoil SSL cert exists
make-ssl-cert generate-default-snakeoil --force-overwrite 2>/dev/null || true

# 11. Database Setup & Schema Initialization
echo "🗃️ Setting up MariaDB 'cpanel_system' database..."
SQL_USER_CMDS="CREATE USER IF NOT EXISTS 'cpanel_admin'@'localhost' IDENTIFIED BY 'cPanelSecurePass2026!'; ALTER USER 'cpanel_admin'@'localhost' IDENTIFIED BY 'cPanelSecurePass2026!'; GRANT ALL PRIVILEGES ON *.* TO 'cpanel_admin'@'localhost' WITH GRANT OPTION; FLUSH PRIVILEGES;"

mariadb -u root -e "$SQL_USER_CMDS" 2>/dev/null || mariadb -e "$SQL_USER_CMDS" 2>/dev/null || mysql -u root -e "$SQL_USER_CMDS" 2>/dev/null || true

if [ -f "${SCRIPT_DIR}/schema.sql" ]; then
    mariadb -u root < "${SCRIPT_DIR}/schema.sql" 2>/dev/null || mariadb -u cpanel_admin -pcPanelSecurePass2026! < "${SCRIPT_DIR}/schema.sql" 2>/dev/null || mysql -u root < "${SCRIPT_DIR}/schema.sql" 2>/dev/null || true
    echo "✅ Database schema loaded successfully."
fi

# 12. Deploy Application Core
echo "🚀 Deploying Cpanel1280 Core to ${APP_DIR}..."
mkdir -p "${APP_DIR}"
cp -rf "${SCRIPT_DIR}/"* "${APP_DIR}/"

if [[ "${SCRIPT_DIR}" == /tmp/* ]]; then
    rm -rf "${SCRIPT_DIR}"
fi
SCRIPT_DIR="${APP_DIR}"

cd "${APP_DIR}"
echo "📦 Installing Node.js production dependencies..."
npm install --omit=dev --loglevel=error

# 12.1 Register Primary Administrator Account with Zero Plain-Text Storage
if [ -n "$ADMIN_EMAIL" ] && [ -n "$ADMIN_PASS" ]; then
    echo "🔒 Registering Primary Administrator Account into MariaDB..."
    ADMIN_BCRYPT_HASH=$(node -e "try { const b = require('bcryptjs'); console.log(b.hashSync(process.argv[1], 10)); } catch(e) { process.exit(1); }" "$ADMIN_PASS" 2>/dev/null || true)
    if [ -n "$ADMIN_BCRYPT_HASH" ]; then
        mariadb -u cpanel_admin -pcPanelSecurePass2026! -e "USE cpanel_system; INSERT INTO users (name, email, password_hash, role) VALUES ('Administrator', '${ADMIN_EMAIL}', '${ADMIN_BCRYPT_HASH}', 'admin') ON DUPLICATE KEY UPDATE email = '${ADMIN_EMAIL}', password_hash = '${ADMIN_BCRYPT_HASH}', role = 'admin';" 2>/dev/null || true
        echo "✅ Administrator account registered securely (Zero plain-text password storage)."
    fi
    unset ADMIN_PASS ADMIN_PASS_CONFIRM
fi

# 13. Setup Systemd Service with Dynamic Node Binary Detection
echo "⚡ Registering systemd background service..."
NODE_BIN=$(command -v node || which node || echo "/usr/bin/node")
if [ ! -f /usr/bin/node ] && [ -f "$NODE_BIN" ]; then
    ln -sf "$NODE_BIN" /usr/bin/node
fi

if [ -f "${SCRIPT_DIR}/configs/systemd/cpanel-core.service" ]; then
    cp -f "${SCRIPT_DIR}/configs/systemd/cpanel-core.service" /etc/systemd/system/cpanel-core.service
    sed -i "s|ExecStart=.*|ExecStart=${NODE_BIN} ${APP_DIR}/server.js|g" /etc/systemd/system/cpanel-core.service
    systemctl daemon-reload
    systemctl enable cpanel-core.service
    systemctl restart cpanel-core.service
fi

# 14. Configure Default Nginx Reverse Proxy & Upload Buffer
echo "🌐 Configuring Nginx reverse proxy..."
if ! grep -q "client_max_body_size" /etc/nginx/nginx.conf; then
    sed -i '/http {/a \    client_max_body_size 2048M;' /etc/nginx/nginx.conf
fi

if [ -f "${SCRIPT_DIR}/configs/nginx/cpanel-nginx.conf" ]; then
    cp -f "${SCRIPT_DIR}/configs/nginx/cpanel-nginx.conf" /etc/nginx/sites-available/default
    ln -sf /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default
    nginx -t && (systemctl restart nginx || systemctl reload nginx) 2>/dev/null || true
fi

# Restart Mail Services
systemctl restart postfix dovecot || true

# 15. Configure Firewall (UFW)
echo "🛡️ Configuring Firewall rules (Ports: 80, 443, 3000, 25, 587, 465, 143, 993, 2525)..."
ufw allow 22/tcp || true
ufw allow 80/tcp || true
ufw allow 443/tcp || true
ufw allow 3000/tcp || true
ufw allow 25/tcp || true
ufw allow 587/tcp || true
ufw allow 465/tcp || true
ufw allow 143/tcp || true
ufw allow 993/tcp || true
ufw allow 110/tcp || true
ufw allow 995/tcp || true
ufw allow 2525/tcp || true

# 16. Install Cloudflare Tunnel Agent (cloudflared) for Zero-Port Instant Access
echo "⚡ Setting up Cloudflare Tunnel Agent (cloudflared)..."
if ! command -v cloudflared >/dev/null 2>&1; then
    ARCH=$(dpkg --print-architecture 2>/dev/null || uname -m)
    case "$ARCH" in
        amd64|x86_64) CF_ARCH="amd64" ;;
        arm64|aarch64) CF_ARCH="arm64" ;;
        arm*) CF_ARCH="arm" ;;
        *) CF_ARCH="amd64" ;;
    esac
    curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${CF_ARCH}" -o /usr/local/bin/cloudflared 2>/dev/null || true
    chmod +x /usr/local/bin/cloudflared 2>/dev/null || true
fi

# 17. Launch Temporary Cloudflare Quick-Tunnel for Zero-Port Web Wizard
CF_TUNNEL_URL=""
if command -v cloudflared >/dev/null 2>&1; then
    echo "🌐 Activating Cloudflare Instant Access Tunnel..."
    mkdir -p /var/log
    rm -f /var/log/cpanel-tunnel.log

    cat << 'EOF' > /etc/systemd/system/cpanel-wizard-tunnel.service
[Unit]
Description=Cpanel1280 Cloudflare Temporary Setup Wizard Tunnel
After=network.target cpanel-core.service

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/cloudflared tunnel --url http://127.0.0.1:3000 --logfile /var/log/cpanel-tunnel.log
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable cpanel-wizard-tunnel.service 2>/dev/null || true
    systemctl restart cpanel-wizard-tunnel.service 2>/dev/null || true

    for i in {1..12}; do
        if [ -f /var/log/cpanel-tunnel.log ]; then
            CF_TUNNEL_URL=$(grep -o 'https://[-a-zA-Z0-9]*\.trycloudflare\.com' /var/log/cpanel-tunnel.log | head -n 1 || true)
            if [ -n "$CF_TUNNEL_URL" ]; then break; fi
        fi
        sleep 1
    done

    if [ -n "$CF_TUNNEL_URL" ]; then
        echo "⏳ Verifying Cloudflare tunnel edge propagation..."
        for i in {1..15}; do
            if curl -s -m 2 -I "${CF_TUNNEL_URL}/tpanel-setup" 2>/dev/null | grep -q "HTTP"; then
                echo "✅ Tunnel active and responding."
                break
            fi
            sleep 1
        done
    fi
fi

# 18. Detect VPS Public IP
SERVER_IP=$(curl -s -4 --connect-timeout 4 https://api.ipify.org || curl -s --connect-timeout 4 https://ifconfig.me || hostname -I | awk '{print $1}')
if [ -z "$SERVER_IP" ]; then
    SERVER_IP="127.0.0.1"
fi

# Store detected IP in system_settings
mariadb -u cpanel_admin -pcPanelSecurePass2026! -e "USE cpanel_system; INSERT INTO system_settings (setting_key, setting_value) VALUES ('server_ip', '${SERVER_IP}') ON DUPLICATE KEY UPDATE setting_value = '${SERVER_IP}';" 2>/dev/null || true

# 19. Generate In-House Branded tPanel Setup Link via Master Hub
TARGET_WIZARD_URL=""
if [ -n "$CF_TUNNEL_URL" ]; then
    TARGET_WIZARD_URL="${CF_TUNNEL_URL}/tpanel-setup"
else
    TARGET_WIZARD_URL="http://${SERVER_IP}/tpanel-setup"
fi

SHORT_TPANEL_LINK=""
RAND_SUFFIX=$(head /dev/urandom | tr -dc '0-9' | head -c 4 2>/dev/null || echo "$((1000 + RANDOM % 9000))")
SESSION_ID="tpanel-${RAND_SUFFIX}"

# Register session with our master hub (hoster1280.shop)
HUB_PAYLOAD=$(printf '{"sessionId":"%s","targetUrl":"%s","serverIp":"%s"}' "$SESSION_ID" "$TARGET_WIZARD_URL" "$SERVER_IP")
HUB_RESP=$(curl -s -A "Mozilla/5.0" -X POST "https://hoster1280.shop/api/hub/register-session" \
    -H "Content-Type: application/json" \
    --connect-timeout 5 \
    -d "$HUB_PAYLOAD" 2>/dev/null || true)

BRANDED_URL=$(echo "$HUB_RESP" | jq -r '.brandedUrl // empty' 2>/dev/null || true)
if [ -z "$BRANDED_URL" ] && [[ "$HUB_RESP" == *"\"ok\":true"* || "$HUB_RESP" == *"\"success\":true"* ]]; then
    BRANDED_URL="https://hoster1280.shop/tpanel-setup/${SESSION_ID}"
fi

if [ -n "$BRANDED_URL" ]; then
    SHORT_TPANEL_LINK="$BRANDED_URL"
else
    SHORT_TPANEL_LINK="https://hoster1280.shop/tpanel-setup/${SESSION_ID}"
fi

mariadb -u cpanel_admin -pcPanelSecurePass2026! -e "USE cpanel_system; INSERT INTO system_settings (setting_key, setting_value) VALUES ('setup_session_id', '${SESSION_ID}') ON DUPLICATE KEY UPDATE setting_value = '${SESSION_ID}';" 2>/dev/null || true
mariadb -u cpanel_admin -pcPanelSecurePass2026! -e "USE cpanel_system; INSERT INTO system_settings (setting_key, setting_value) VALUES ('short_setup_url', '${SHORT_TPANEL_LINK}') ON DUPLICATE KEY UPDATE setting_value = '${SHORT_TPANEL_LINK}';" 2>/dev/null || true

echo ""
echo "=========================================================================="
echo "  🎉 CONGRATULATIONS! TPANEL ENGINE INSTALLED SUCCESSFULLY!"
echo "=========================================================================="
echo ""
echo "  🔑 ACTIVE LICENSE : Bound & Verified with Central Hub"
if [ -n "$ADMIN_EMAIL" ]; then
echo "  👤 PRIMARY ADMIN  : ${ADMIN_EMAIL} (Password securely hashed with bcrypt)"
fi
echo ""
if [ -n "$SHORT_TPANEL_LINK" ]; then
echo "  👉 🚀 OFFICIAL TPANEL SETUP LINK (অফিসিয়াল নিজস্ব ব্র্যান্ডেড সেটআপ লিঙ্ক):"
echo "     ${SHORT_TPANEL_LINK}"
echo ""
elif [ -n "$CF_TUNNEL_URL" ]; then
echo "  👉 🌟 DIRECT INSTANT ACCESS LINK (ইনস্ট্যান্ট এক্সেস লিঙ্ক):"
echo "     ${CF_TUNNEL_URL}/tpanel-setup"
echo ""
fi
echo "  👉 🌐 DIRECT VPS IP LINK (সাধারণ ডেডিকেটেড আইপি এক্সেস):"
echo "     http://${SERVER_IP}/tpanel-setup"
echo "     (or direct port 3000: http://${SERVER_IP}:3000/tpanel-setup)"
echo ""
echo "  📋 NEXT STEPS (পরবর্তী করণীয় ধাপসমূহ):"
echo "  1. Open the branded tPanel setup link in your browser."
echo "     (যেকোনো ব্রাউজারে উপরের ব্র্যান্ডেড লিংকে প্রবেশ করুন)"
echo "  2. Enter your master domain (e.g. yourdomain.com) to complete DNS & SSL."
echo "  3. Select Cloudflare Auto-Pilot (Yes) or Manual DNS (No):"
echo "     • Yes / হ্যাঁ: Provide Cloudflare API token for instant 1-click sync."
echo "     • No / না   : Copy the 7 pre-configured DNS records to your registrar."
echo "  4. Click 'Complete Setup' - your panel will be live immediately:"
echo "     👉 https://yourdomain.com/tpanel"
echo "     (সেটআপ সম্পন্ন হওয়ামাত্র উইজার্ডটি স্বয়ংক্রিয়ভাবে চিরতরে লক হয়ে যাবে)"
echo ""
echo "  🛠️ SYSTEM SERVICES STATUS:"
echo "     • Tpanel Core Engine : systemctl status cpanel-core"
echo "     • Nginx Web Server   : systemctl status nginx"
echo "     • MariaDB Database   : systemctl status mariadb"
echo "     • Postfix Mail MTA   : systemctl status postfix"
echo "     • Dovecot Maildir    : systemctl status dovecot"
echo "=========================================================================="
echo ""

